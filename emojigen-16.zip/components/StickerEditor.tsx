import React, { useState, useEffect } from 'react';
import { StickerData } from '../types';

interface StickerEditorProps {
  sticker: StickerData;
  isOpen: boolean;
  onClose: () => void;
  onUpdate: (id: number, newCaption: string) => void;
  onRegenerate: (id: number) => void;
}

export const StickerEditor: React.FC<StickerEditorProps> = ({ 
  sticker, isOpen, onClose, onUpdate, onRegenerate 
}) => {
  const [caption, setCaption] = useState(sticker.caption);

  useEffect(() => {
    setCaption(sticker.caption);
  }, [sticker]);

  if (!isOpen) return null;

  const handleSave = () => {
    onUpdate(sticker.id, caption);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col max-h-[90vh]">
        <div className="p-4 border-b border-gray-100 flex justify-between items-center">
          <h3 className="font-bold text-gray-800">Edit Sticker</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
          </button>
        </div>

        <div className="p-6 flex flex-col items-center gap-6 overflow-y-auto">
          {/* Preview Canvas */}
          <div className="w-60 h-60 bg-[url('https://www.transparenttextures.com/patterns/checkerboard-cross.png')] bg-gray-50 rounded-lg border border-gray-200 flex items-center justify-center shadow-inner relative group">
             {sticker.status === 'processing' || sticker.status === 'generating' ? (
                 <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-blue-600"></div>
             ) : (
                <img 
                    src={sticker.processedImageUrl || sticker.rawImageUrl || ''} 
                    alt="Preview" 
                    className="w-full h-full object-contain"
                />
             )}
          </div>

          <div className="w-full space-y-4">
             <div>
               <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Caption</label>
               <input
                 type="text"
                 value={caption}
                 onChange={(e) => setCaption(e.target.value)}
                 className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-center font-bold text-lg"
                 maxLength={6}
               />
               <p className="text-xs text-gray-400 mt-1 text-center">Max 6 chars. Update re-renders text on image.</p>
             </div>

             <div className="pt-4 border-t border-gray-100">
               <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Actions</label>
               <button 
                  onClick={() => { onRegenerate(sticker.id); onClose(); }}
                  className="w-full py-2.5 px-4 bg-gray-50 hover:bg-gray-100 text-gray-700 rounded-lg border border-gray-200 font-medium transition flex items-center justify-center gap-2 mb-3"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.3"/></svg>
                  Regenerate Image (AI)
               </button>
             </div>
          </div>
        </div>

        <div className="p-4 bg-gray-50 border-t border-gray-200 flex justify-end gap-3">
          <button onClick={onClose} className="px-4 py-2 text-gray-600 hover:text-gray-800 font-medium">Cancel</button>
          <button onClick={handleSave} className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium shadow-sm active:scale-95 transition">
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};
