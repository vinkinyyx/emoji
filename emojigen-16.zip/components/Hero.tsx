import React, { useState } from 'react';

interface HeroProps {
  onGenerate: (topic: string, style: string) => void;
  isProcessing: boolean;
}

export const Hero: React.FC<HeroProps> = ({ onGenerate, isProcessing }) => {
  const [topic, setTopic] = useState('');
  const [style, setStyle] = useState('Cute Flat Vector');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (topic.trim()) {
      onGenerate(topic, style);
    }
  };

  return (
    <div className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-5xl mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex-1 w-full">
            <h1 className="text-2xl font-bold text-gray-800 mb-2 flex items-center gap-2">
              <span className="text-3xl">🎨</span> EmojiGen 16
            </h1>
            <p className="text-gray-500 text-sm">One prompt, 16 consistent WeChat stickers.</p>
          </div>

          <form onSubmit={handleSubmit} className="flex-1 w-full flex flex-col sm:flex-row gap-3">
            <div className="flex-grow flex flex-col gap-1">
              <input
                type="text"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="Ex: Programmer Cat, Sleepy Panda..."
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
                disabled={isProcessing}
              />
            </div>
            <div className="w-full sm:w-40 flex flex-col gap-1">
               <select 
                  value={style}
                  onChange={(e) => setStyle(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 bg-white focus:ring-2 focus:ring-blue-500 outline-none"
                  disabled={isProcessing}
               >
                 <option value="Cute Flat Vector">Cute Vector</option>
                 <option value="3D Clay Render">3D Clay</option>
                 <option value="Hand Drawn Sketch">Hand Drawn</option>
                 <option value="Pixel Art">Pixel Art</option>
               </select>
            </div>
            <button
              type="submit"
              disabled={isProcessing || !topic.trim()}
              className={`px-6 py-3 rounded-lg font-semibold text-white transition shadow-sm whitespace-nowrap
                ${isProcessing || !topic.trim() 
                  ? 'bg-gray-400 cursor-not-allowed' 
                  : 'bg-blue-600 hover:bg-blue-700 active:scale-95'}`}
            >
              {isProcessing ? 'Creating...' : 'Generate Pack'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
