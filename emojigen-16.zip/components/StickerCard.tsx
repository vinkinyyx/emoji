import React from 'react';
import { StickerData } from '../types';
import { EMOTION_LABELS } from '../constants';

interface StickerCardProps {
  data: StickerData;
  onClick: () => void;
}

export const StickerCard: React.FC<StickerCardProps> = ({ data, onClick }) => {
  return (
    <div 
      onClick={onClick}
      className="group relative bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden cursor-pointer hover:shadow-md transition-all duration-200 aspect-square flex flex-col"
    >
      <div className="absolute top-2 left-2 bg-black/50 backdrop-blur-sm text-white text-xs px-2 py-0.5 rounded-full z-10">
        {EMOTION_LABELS[data.emotion] || data.emotion}
      </div>

      <div className="flex-1 flex items-center justify-center p-4 bg-[url('https://www.transparenttextures.com/patterns/checkerboard-cross.png')] bg-gray-50">
        {data.status === 'pending' && (
          <div className="w-8 h-8 rounded-full border-2 border-gray-300 border-t-transparent animate-spin"></div>
        )}
        
        {(data.status === 'generating' || data.status === 'processing') && (
           <div className="flex flex-col items-center gap-2">
             <div className="w-8 h-8 rounded-full border-2 border-blue-500 border-t-transparent animate-spin"></div>
             <span className="text-xs text-blue-500 font-medium">AI Working...</span>
           </div>
        )}

        {data.status === 'error' && (
          <span className="text-red-400 text-xs text-center">Failed</span>
        )}

        {data.status === 'complete' && data.processedImageUrl && (
          <img 
            src={data.processedImageUrl} 
            alt={data.emotion} 
            className="w-full h-full object-contain drop-shadow-sm group-hover:scale-105 transition-transform duration-300" 
          />
        )}
      </div>

      <div className="h-10 border-t border-gray-100 flex items-center justify-center bg-white">
        <span className="text-sm font-medium text-gray-700 truncate px-2">
          {data.caption}
        </span>
      </div>

      {/* Hover Overlay */}
      <div className="absolute inset-0 bg-blue-900/0 group-hover:bg-blue-900/10 transition-colors flex items-center justify-center">
         {data.status === 'complete' && (
           <div className="opacity-0 group-hover:opacity-100 bg-white text-blue-600 rounded-full p-2 shadow-lg transform translate-y-2 group-hover:translate-y-0 transition-all">
             <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg>
           </div>
         )}
      </div>
    </div>
  );
};
