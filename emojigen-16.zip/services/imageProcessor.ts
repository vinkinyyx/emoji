import { STICKER_SIZE } from "../constants";

/**
 * Loads an image from a URL or Base64 string
 */
const loadImage = (src: string): Promise<HTMLImageElement> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "Anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
};

/**
 * Processes the raw image:
 * 1. Resizes to 240x240
 * 2. Simulates background removal (White to Transparent)
 * 3. Adds a white stroke/border
 * 4. Adds text overlay if provided
 */
export const processStickerImage = async (
  rawBase64: string,
  caption: string
): Promise<string> => {
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) throw new Error("Canvas not supported");

  canvas.width = STICKER_SIZE;
  canvas.height = STICKER_SIZE;

  const img = await loadImage(rawBase64);

  // 1. Draw scaled image (Fit within 240x240 with padding for stroke)
  const padding = 10;
  const drawSize = STICKER_SIZE - padding * 2;
  
  // Calculate aspect ratio to fit
  const scale = Math.min(drawSize / img.width, drawSize / img.height);
  const w = img.width * scale;
  const h = img.height * scale;
  const x = (STICKER_SIZE - w) / 2;
  const y = (STICKER_SIZE - h) / 2;

  // Temp canvas for processing pixels
  const tempCanvas = document.createElement('canvas');
  tempCanvas.width = STICKER_SIZE;
  tempCanvas.height = STICKER_SIZE;
  const tempCtx = tempCanvas.getContext('2d', { willReadFrequently: true });
  if (!tempCtx) throw new Error("Temp Canvas fail");

  tempCtx.drawImage(img, x, y, w, h);

  // 2. Simple Background Removal (White Keying)
  // Since we prompt for "white background", we make near-white pixels transparent.
  const frameData = tempCtx.getImageData(0, 0, STICKER_SIZE, STICKER_SIZE);
  const data = frameData.data;
  const threshold = 230; // White threshold

  // Create a mask for stroke generation
  // 0 = empty, 1 = occupied
  const mask = new Uint8Array(STICKER_SIZE * STICKER_SIZE);

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    // If pixel is very light/white, make it transparent
    if (r > threshold && g > threshold && b > threshold) {
      data[i + 3] = 0; // Alpha 0
      mask[i / 4] = 0;
    } else {
      mask[i / 4] = 1;
    }
  }

  // Put the cleared image back to tempCtx
  tempCtx.putImageData(frameData, 0, 0);

  // 3. Generate Stroke (White Border)
  // We dilate the mask to create a border area
  const strokeWidth = 3;
  ctx.fillStyle = "#FFFFFF";
  
  // Simple dilation algorithm for stroke
  // For every pixel, if it's part of the image, draw a white circle on the main canvas
  // This is computationally expensive in JS, optimizing by checking mask.
  // A better approach for performance: Draw the image 8 times at offset positions.
  
  // Clear main canvas
  ctx.clearRect(0, 0, STICKER_SIZE, STICKER_SIZE);

  // Draw stroke by offsetting (Simulated stroke)
  // This is faster than per-pixel manipulation in JS
  const offsets = [-2, 0, 2];
  ctx.globalCompositeOperation = 'source-over';
  // Draw the "white silhouette" first
  // We use the tempCtx (transparent image) and draw it with brightness filter or just standard drawing if we assume internal pixels are opaque enough. 
  // Actually, to get a solid white stroke, we can iterate the mask.
  
  // Optimization: use shadowBlur? Standard canvas shadows are soft. We need hard edge.
  // Let's use the offset approach with the CLEARED image.
  
  ctx.filter = 'brightness(0) invert(1)'; // Make it white (if image was dark) - actually strictly white needed.
  // Better: loop through mask and draw rectangles.
  // Let's stick to the multi-draw approach, it's "good enough" for stickers.
  
  // Create a white silhouette version of the cut-out image
  const silhouetteCanvas = document.createElement('canvas');
  silhouetteCanvas.width = STICKER_SIZE;
  silhouetteCanvas.height = STICKER_SIZE;
  const sCtx = silhouetteCanvas.getContext('2d');
  if(sCtx) {
    sCtx.drawImage(tempCanvas, 0, 0);
    sCtx.globalCompositeOperation = 'source-in';
    sCtx.fillStyle = 'white';
    sCtx.fillRect(0, 0, STICKER_SIZE, STICKER_SIZE);
  }

  // Draw silhouette at offsets
  for (let ox = -strokeWidth; ox <= strokeWidth; ox++) {
      for (let oy = -strokeWidth; oy <= strokeWidth; oy++) {
          if (ox*ox + oy*oy <= strokeWidth*strokeWidth) {
               ctx.drawImage(silhouetteCanvas, ox, oy);
          }
      }
  }

  // 4. Draw Original Cut-out Image on top
  ctx.filter = 'none';
  ctx.globalCompositeOperation = 'source-over';
  ctx.drawImage(tempCanvas, 0, 0);

  // 5. Add Caption (If needs text synthesis)
  if (caption) {
    ctx.fillStyle = "white";
    ctx.strokeStyle = "black";
    ctx.lineWidth = 3;
    ctx.font = "bold 24px 'Noto Sans SC', sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "bottom";
    
    const tx = STICKER_SIZE / 2;
    const ty = STICKER_SIZE - 10;

    // Stroke text
    ctx.strokeText(caption, tx, ty);
    // Fill text
    ctx.fillText(caption, tx, ty);
  }

  return canvas.toDataURL("image/png");
};

export const createZipPackage = async (stickers: any[]) => {
  const zip = new window.JSZip();
  const folder = zip.folder("wechat_stickers");

  // 1. Add Main Sticker Images (240x240)
  for (let i = 0; i < stickers.length; i++) {
    const s = stickers[i];
    if (s.processedImageUrl) {
      const base64Data = s.processedImageUrl.split(',')[1];
      folder.file(`sticker_${i + 1}_${s.emotion}.png`, base64Data, { base64: true });
    }
  }

  // 2. Add Cover/Icons (Derived from first sticker for demo purposes)
  if (stickers.length > 0 && stickers[0].processedImageUrl) {
      const coverData = stickers[0].processedImageUrl.split(',')[1];
      folder.file(`cover_240x240.png`, coverData, {base64: true});
      // In a real app, we would resize these specifically to 50x50, etc.
  }

  const content = await zip.generateAsync({ type: "blob" });
  window.saveAs(content, "emojigen_pack.zip");
};
