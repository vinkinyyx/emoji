import { GoogleGenAI, Type } from "@google/genai";
import { EMOTIONS, EMOTION_LABELS } from "../constants";
import { StickerPlan } from "../types";

// Initialize Gemini Client
// WARNING: In a real production app, never expose keys in client code.
// For this demo, we assume process.env.API_KEY is available via build tool.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Step 1: PLAN
 * Generates prompts for 16 stickers based on a topic to ensure consistency.
 */
export const planStickerPack = async (topic: string, style: string): Promise<StickerPlan[]> => {
  const model = "gemini-3-flash-preview";
  
  const systemInstruction = `You are a professional WeChat Sticker Art Director. 
  Your goal is to plan a pack of 16 stickers based on a user Topic and Style.
  
  CRITICAL RULES:
  1. Character Consistency: Define a specific visual description (colors, breed, clothing, accessories) that is repeated in every prompt.
  2. Style Consistency: Use the user's style preference (e.g., pixel art, flat vector, watercolor). Default to "flat vector sticker, white background, bold lines" if unspecified.
  3. Output JSON only.
  4. The captions must be short, witty, Chinese internet slang appropriate for the emotion.
  `;

  const prompt = `
    Topic: ${topic}
    Style: ${style}
    
    Required Emotions: ${EMOTIONS.join(', ')}
    
    Generate a JSON response containing an array of 16 items.
    Each item must have:
    - id: number (1-16)
    - emotion: one of the required emotions
    - caption: Chinese text overlay (max 4 chars)
    - visualPrompt: A detailed English prompt for an image generator. It MUST start with "white background, sticker design, vector art". It MUST include the detailed character description.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.INTEGER },
              emotion: { type: Type.STRING },
              caption: { type: Type.STRING },
              visualPrompt: { type: Type.STRING },
            },
            required: ["id", "emotion", "caption", "visualPrompt"],
          },
        },
      },
    });

    if (response.text) {
      return JSON.parse(response.text) as StickerPlan[];
    }
    throw new Error("Empty response from AI Planner");
  } catch (error) {
    console.error("Planning failed:", error);
    throw error;
  }
};

/**
 * Step 2: PAINT
 * Generates a single image based on the prompt.
 */
export const generateStickerImage = async (visualPrompt: string): Promise<string> => {
  // Using the efficient flash image model for speed and sticker aesthetic
  const model = "gemini-2.5-flash-image"; 

  try {
    const response = await ai.models.generateContent({
      model,
      contents: visualPrompt,
      config: {
        // Image generation specific config not strictly typed in all SDK versions yet, 
        // but 'generateContent' handles prompt-to-image on multimodal models.
        // We rely on the text prompt to enforce "1:1" aspect ratio via model capability if config isn't exposed.
        // Ideally we check if imageConfig is available. 
        // For gemini-2.5-flash-image, we just send the text.
      }
    });

    // Extract image
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image data found in response");
  } catch (error) {
    console.error("Image generation failed:", error);
    throw error;
  }
};
